import {App,Page,Platform} from 'ionic-angular';
import {Camera} from 'ionic-native';
import {Http, Headers, RequestOptions} from '../../../node_modules/angular2/http';
import {Inject} from '../../../node_modules/angular2/core';
import 'rxjs/add/operator/map';

@Page({
  templateUrl: 'build/pages/home/home.html'
})
export class HomePage {

    // static get parameters(){
    //   return [Camera];
    // }
    navigator:any;
    camera:any;
    http:any;
    platform:any;

    constructor(httpService: Http) {//pass in camera
      // Camera = camera;
      // console.log(navigator);
      console.log(Camera);
      //this.scan();
      this.http = httpService;

    }

    scan(){

      var options = {
        destinationType:Camera.DestinationType.DATA_URL,
        //sourceType 0 for library, 1 for camera and 2 for saveToPhotoAlbum
        //originally Camera.EncodingType.JPEG
        sourceType: Camera.PictureSourceType.CAMERA,
        quality:75,
        allowEdit:false,
        saveToPhotoAlbum: false
      };

      Camera.getPicture(options).then((imageData) => {
        // imageData is either a base64 encoded string or a file URI
        // If it's base64:
        let base64Image = "data:image/jpeg;base64," + imageData;
        console.log(imageData);
          //Do something

          this.cameraSuccessCallback(imageData);

      }, (err) => {
          alert(err);
      });
    };

    cameraSuccessCallback(imageData){
      console.log('called camera success callback');

      let data = this.getApi(imageData);

      // console.log(data);

      data.subscribe(
        res => {
          console.log(res);
        }
      )
    };

    getApi(imageData){
    console.log('called getapi');
    // return this.http.post({
    //     url: "https://api.projectoxford.ai/emotion/v1.0/recognize" + imageData,
    //     beforeSend: function(xhrObj){
    //         // Request headers
    //         xhrObj.setRequestHeader("Content-Type","application/json");
    //         xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key","ace9d00d65f74aa9b39b58d84384c548");
    //     },
    //     type: "POST",
    //     // Request body
    //     data: imageData,
    //     //pass in image data
    //     }).then(function sucessCallBack(response) {
    //     alert("success");
    //     console.log(response);
    //   }, function errorCallBack(response){
    //     alert("failed");
    //     console.log(response);
    //   });

    let headers = new Headers({
      // 'Content-Type':'application/json',
      'AuthKey':'12c6ae2b1dfd16038fc2'
      // 'Ocp-Apim-Subscription-Key':'ace9d00d65f74aa9b39b58d84384c548'
    });

    let options = new RequestOptions({headers:headers});

    return this.http.post(
      "https://api.pastec.io/indexes/vygfzrfgnqjwmmzzcvae/searcher" ,
      imageData,
      options).map(res => res.json());
    }
};

  //     })
  //     function(){
  //       $.ajax({
  //           url: "https://api.projectoxford.ai/emotion/v1.0/recognize",
  //           beforeSend: function(xhrObj){
  //               // Request headers
  //               xhrObj.setRequestHeader("Content-Type","application/json");
  //               xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key","ace9d00d65f74aa9b39b58d84384c548");
  //           },
  //           type: "POST",
  //           // Request body
  //           data: imageData,
  //           //pass in image data
  //       })
  //       .done(function(data) {
  //           alert("success");
  //       })
  //       .fail(function() {
  //           alert("error");
  //       });
  //
  //     //Google Api
  //   }
  // })
